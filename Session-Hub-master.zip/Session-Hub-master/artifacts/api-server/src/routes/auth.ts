import { Router, type IRouter } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { generateToken, requireAuth, type AuthenticatedRequest } from "../middlewares/auth.js";

const router: IRouter = Router();

const GITHUB_CLIENT_ID = process.env.GITHUB_CLIENT_ID || "";
const GITHUB_CLIENT_SECRET = process.env.GITHUB_CLIENT_SECRET || "";
const FRONTEND_URL = process.env.FRONTEND_URL || "";

router.get("/github", (_req, res) => {
  const params = new URLSearchParams({
    client_id: GITHUB_CLIENT_ID,
    scope: "user:email",
    redirect_uri: `${FRONTEND_URL ? FRONTEND_URL : ""}/api/auth/github/callback`,
  });
  res.redirect(`https://github.com/login/oauth/authorize?${params.toString()}`);
});

router.get("/github/callback", async (req, res) => {
  const { code } = req.query as { code: string };

  if (!code) {
    res.status(400).json({ message: "Missing OAuth code" });
    return;
  }

  try {
    const tokenRes = await fetch("https://github.com/login/oauth/access_token", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        client_id: GITHUB_CLIENT_ID,
        client_secret: GITHUB_CLIENT_SECRET,
        code,
      }),
    });

    const tokenData = await tokenRes.json() as { access_token?: string; error?: string };

    if (!tokenData.access_token) {
      res.status(400).json({ message: "Failed to get access token from GitHub" });
      return;
    }

    const userRes = await fetch("https://api.github.com/user", {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
        Accept: "application/json",
      },
    });

    const githubUser = await userRes.json() as {
      id: number;
      login: string;
      name: string | null;
      email: string | null;
      avatar_url: string;
    };

    const githubId = String(githubUser.id);

    const [existingUser] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.githubId, githubId))
      .limit(1);

    let user;
    if (existingUser) {
      const [updated] = await db
        .update(usersTable)
        .set({
          name: githubUser.name || githubUser.login,
          avatarUrl: githubUser.avatar_url,
        })
        .where(eq(usersTable.githubId, githubId))
        .returning();
      user = updated;
    } else {
      const [created] = await db
        .insert(usersTable)
        .values({
          githubId,
          name: githubUser.name || githubUser.login,
          email: githubUser.email,
          avatarUrl: githubUser.avatar_url,
          role: "user",
        })
        .returning();
      user = created;
    }

    const token = generateToken(user.id);

    const frontendBase = FRONTEND_URL || "";
    res.redirect(`${frontendBase}/auth/callback?token=${token}`);
  } catch (err) {
    console.error("OAuth error:", err);
    res.status(500).json({ message: "Authentication failed" });
  }
});

router.get("/me", requireAuth, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  res.json({
    id: user.id,
    githubId: user.githubId,
    name: user.name,
    email: user.email ?? null,
    avatarUrl: user.avatarUrl ?? null,
    bio: user.bio ?? null,
    role: user.role,
    createdAt: user.createdAt,
  });
});

router.post("/logout", (_req, res) => {
  res.json({ message: "Logged out successfully" });
});

export default router;
