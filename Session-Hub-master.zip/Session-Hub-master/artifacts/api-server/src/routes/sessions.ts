import { Router, type IRouter } from "express";
import { db, sessionsTable, usersTable, bookingsTable } from "@workspace/db";
import { eq, ilike, and, count, sql } from "drizzle-orm";
import { requireAuth, requireCreator, type AuthenticatedRequest } from "../middlewares/auth.js";

const router: IRouter = Router();

function formatUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    githubId: user.githubId,
    name: user.name,
    email: user.email ?? null,
    avatarUrl: user.avatarUrl ?? null,
    bio: user.bio ?? null,
    role: user.role,
    createdAt: user.createdAt,
  };
}

async function getBookingCount(sessionId: number): Promise<number> {
  const result = await db
    .select({ count: count() })
    .from(bookingsTable)
    .where(and(eq(bookingsTable.sessionId, sessionId), eq(bookingsTable.status, "active")));
  return result[0]?.count ?? 0;
}

router.get("/creator/my", requireAuth, requireCreator, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;

  const sessions = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.creatorId, user.id))
    .orderBy(sessionsTable.createdAt);

  const sessionsWithCounts = await Promise.all(
    sessions.map(async (session) => {
      const bookingCount = await getBookingCount(session.id);
      return {
        ...session,
        creator: formatUser(user),
        bookingCount,
      };
    })
  );

  res.json({ sessions: sessionsWithCounts, total: sessionsWithCounts.length, page: 1, limit: sessionsWithCounts.length });
});

router.get("/", async (req, res) => {
  const { category, search, page = "1", limit = "12" } = req.query as {
    category?: string;
    search?: string;
    page?: string;
    limit?: string;
  };

  const pageNum = parseInt(page, 10) || 1;
  const limitNum = parseInt(limit, 10) || 12;
  const offset = (pageNum - 1) * limitNum;

  const conditions = [eq(sessionsTable.isActive, true)];

  if (category) {
    conditions.push(eq(sessionsTable.category, category));
  }
  if (search) {
    conditions.push(ilike(sessionsTable.title, `%${search}%`));
  }

  const whereClause = conditions.length === 1 ? conditions[0] : and(...conditions);

  const [totalResult, sessions] = await Promise.all([
    db
      .select({ count: count() })
      .from(sessionsTable)
      .where(whereClause),
    db
      .select()
      .from(sessionsTable)
      .where(whereClause)
      .limit(limitNum)
      .offset(offset)
      .orderBy(sessionsTable.scheduledAt),
  ]);

  const total = totalResult[0]?.count ?? 0;

  const sessionsWithCreators = await Promise.all(
    sessions.map(async (session) => {
      const [creator] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, session.creatorId))
        .limit(1);
      const bookingCount = await getBookingCount(session.id);
      return {
        ...session,
        creator: formatUser(creator),
        bookingCount,
      };
    })
  );

  res.json({ sessions: sessionsWithCreators, total, page: pageNum, limit: limitNum });
});

router.get("/:id", async (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) {
    res.status(404).json({ message: "Session not found" });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, id))
    .limit(1);

  if (!session) {
    res.status(404).json({ message: "Session not found" });
    return;
  }

  const [creator] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, session.creatorId))
    .limit(1);

  const bookingCount = await getBookingCount(session.id);

  res.json({ ...session, creator: formatUser(creator), bookingCount });
});

router.post("/", requireAuth, requireCreator, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const { title, description, category, price, duration, maxParticipants, scheduledAt, imageUrl } =
    req.body as {
      title: string;
      description: string;
      category: string;
      price: number;
      duration: number;
      maxParticipants?: number | null;
      scheduledAt: string;
      imageUrl?: string | null;
    };

  const [session] = await db
    .insert(sessionsTable)
    .values({
      title,
      description,
      category,
      price,
      duration,
      maxParticipants: maxParticipants ?? null,
      scheduledAt: new Date(scheduledAt),
      imageUrl: imageUrl ?? null,
      isActive: true,
      creatorId: user.id,
    })
    .returning();

  res.status(201).json({ ...session, creator: formatUser(user), bookingCount: 0 });
});

router.put("/:id", requireAuth, requireCreator, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const id = parseInt(req.params.id, 10);

  const [existing] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, id))
    .limit(1);

  if (!existing) {
    res.status(404).json({ message: "Session not found" });
    return;
  }

  if (existing.creatorId !== user.id) {
    res.status(403).json({ message: "Not authorized to update this session" });
    return;
  }

  const { title, description, category, price, duration, maxParticipants, scheduledAt, imageUrl, isActive } =
    req.body as {
      title?: string;
      description?: string;
      category?: string;
      price?: number;
      duration?: number;
      maxParticipants?: number | null;
      scheduledAt?: string;
      imageUrl?: string | null;
      isActive?: boolean;
    };

  const updates: Record<string, unknown> = {};
  if (title !== undefined) updates.title = title;
  if (description !== undefined) updates.description = description;
  if (category !== undefined) updates.category = category;
  if (price !== undefined) updates.price = price;
  if (duration !== undefined) updates.duration = duration;
  if (maxParticipants !== undefined) updates.maxParticipants = maxParticipants;
  if (scheduledAt !== undefined) updates.scheduledAt = new Date(scheduledAt);
  if (imageUrl !== undefined) updates.imageUrl = imageUrl;
  if (isActive !== undefined) updates.isActive = isActive;

  const [updated] = await db
    .update(sessionsTable)
    .set(updates)
    .where(eq(sessionsTable.id, id))
    .returning();

  const bookingCount = await getBookingCount(id);

  res.json({ ...updated, creator: formatUser(user), bookingCount });
});

router.delete("/:id", requireAuth, requireCreator, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const id = parseInt(req.params.id, 10);

  const [existing] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, id))
    .limit(1);

  if (!existing) {
    res.status(404).json({ message: "Session not found" });
    return;
  }

  if (existing.creatorId !== user.id) {
    res.status(403).json({ message: "Not authorized to delete this session" });
    return;
  }

  await db.delete(sessionsTable).where(eq(sessionsTable.id, id));

  res.json({ message: "Session deleted successfully" });
});

router.get("/:id/bookings", requireAuth, requireCreator, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const id = parseInt(req.params.id, 10);

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(and(eq(sessionsTable.id, id), eq(sessionsTable.creatorId, user.id)))
    .limit(1);

  if (!session) {
    res.status(404).json({ message: "Session not found" });
    return;
  }

  const bookings = await db
    .select()
    .from(bookingsTable)
    .where(eq(bookingsTable.sessionId, id));

  const bookingsWithDetails = await Promise.all(
    bookings.map(async (booking) => {
      const [bookingUser] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, booking.userId))
        .limit(1);
      const bookingCount = await getBookingCount(session.id);
      return {
        ...booking,
        session: { ...session, creator: formatUser(user), bookingCount },
        user: formatUser(bookingUser),
      };
    })
  );

  res.json({ bookings: bookingsWithDetails, total: bookingsWithDetails.length });
});

export default router;
