import { Router, type IRouter } from "express";
import { db, bookingsTable, sessionsTable, usersTable } from "@workspace/db";
import { eq, and, count } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth.js";

const router: IRouter = Router();

function formatUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    githubId: user.githubId,
    name: user.name,
    email: user.email ?? null,
    avatarUrl: user.avatarUrl ?? null,
    bio: user.bio ?? null,
    role: user.role,
    createdAt: user.createdAt,
  };
}

async function getBookingCount(sessionId: number): Promise<number> {
  const result = await db
    .select({ count: count() })
    .from(bookingsTable)
    .where(and(eq(bookingsTable.sessionId, sessionId), eq(bookingsTable.status, "active")));
  return result[0]?.count ?? 0;
}

router.get("/", requireAuth, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;

  const bookings = await db
    .select()
    .from(bookingsTable)
    .where(eq(bookingsTable.userId, user.id))
    .orderBy(bookingsTable.createdAt);

  const bookingsWithDetails = await Promise.all(
    bookings.map(async (booking) => {
      const [session] = await db
        .select()
        .from(sessionsTable)
        .where(eq(sessionsTable.id, booking.sessionId))
        .limit(1);

      const [creator] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, session.creatorId))
        .limit(1);

      const bookingCount = await getBookingCount(session.id);

      return {
        ...booking,
        session: { ...session, creator: formatUser(creator), bookingCount },
        user: formatUser(user),
      };
    })
  );

  res.json({ bookings: bookingsWithDetails, total: bookingsWithDetails.length });
});

router.post("/", requireAuth, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const { sessionId } = req.body as { sessionId: number };

  if (!sessionId) {
    res.status(400).json({ message: "sessionId is required" });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, sessionId))
    .limit(1);

  if (!session) {
    res.status(404).json({ message: "Session not found" });
    return;
  }

  if (!session.isActive) {
    res.status(400).json({ message: "Session is not active" });
    return;
  }

  const [existingBooking] = await db
    .select()
    .from(bookingsTable)
    .where(
      and(
        eq(bookingsTable.userId, user.id),
        eq(bookingsTable.sessionId, sessionId),
        eq(bookingsTable.status, "active")
      )
    )
    .limit(1);

  if (existingBooking) {
    res.status(400).json({ message: "You have already booked this session" });
    return;
  }

  if (session.maxParticipants !== null) {
    const currentCount = await getBookingCount(sessionId);
    if (currentCount >= session.maxParticipants) {
      res.status(400).json({ message: "Session is full" });
      return;
    }
  }

  const [booking] = await db
    .insert(bookingsTable)
    .values({
      sessionId,
      userId: user.id,
      status: "active",
    })
    .returning();

  const [creator] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, session.creatorId))
    .limit(1);

  const bookingCount = await getBookingCount(session.id);

  res.status(201).json({
    ...booking,
    session: { ...session, creator: formatUser(creator), bookingCount },
    user: formatUser(user),
  });
});

router.get("/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const id = parseInt(req.params.id, 10);

  const [booking] = await db
    .select()
    .from(bookingsTable)
    .where(and(eq(bookingsTable.id, id), eq(bookingsTable.userId, user.id)))
    .limit(1);

  if (!booking) {
    res.status(404).json({ message: "Booking not found" });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, booking.sessionId))
    .limit(1);

  const [creator] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, session.creatorId))
    .limit(1);

  const bookingCount = await getBookingCount(session.id);

  res.json({
    ...booking,
    session: { ...session, creator: formatUser(creator), bookingCount },
    user: formatUser(user),
  });
});

router.delete("/:id", requireAuth, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const id = parseInt(req.params.id, 10);

  const [booking] = await db
    .select()
    .from(bookingsTable)
    .where(and(eq(bookingsTable.id, id), eq(bookingsTable.userId, user.id)))
    .limit(1);

  if (!booking) {
    res.status(404).json({ message: "Booking not found" });
    return;
  }

  await db
    .update(bookingsTable)
    .set({ status: "cancelled" })
    .where(eq(bookingsTable.id, id));

  res.json({ message: "Booking cancelled successfully" });
});

export default router;
