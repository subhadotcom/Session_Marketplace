import { Router, type IRouter } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth.js";

const router: IRouter = Router();

router.get("/profile", requireAuth, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  res.json({
    id: user.id,
    githubId: user.githubId,
    name: user.name,
    email: user.email ?? null,
    avatarUrl: user.avatarUrl ?? null,
    bio: user.bio ?? null,
    role: user.role,
    createdAt: user.createdAt,
  });
});

router.put("/profile", requireAuth, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const { name, bio, avatarUrl } = req.body as {
    name?: string;
    bio?: string | null;
    avatarUrl?: string | null;
  };

  const updates: Partial<{ name: string; bio: string | null; avatarUrl: string | null }> = {};
  if (name !== undefined) updates.name = name;
  if (bio !== undefined) updates.bio = bio;
  if (avatarUrl !== undefined) updates.avatarUrl = avatarUrl;

  const [updated] = await db
    .update(usersTable)
    .set(updates)
    .where(eq(usersTable.id, user.id))
    .returning();

  res.json({
    id: updated.id,
    githubId: updated.githubId,
    name: updated.name,
    email: updated.email ?? null,
    avatarUrl: updated.avatarUrl ?? null,
    bio: updated.bio ?? null,
    role: updated.role,
    createdAt: updated.createdAt,
  });
});

router.put("/role", requireAuth, async (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const { role } = req.body as { role: "user" | "creator" };

  if (!["user", "creator"].includes(role)) {
    res.status(400).json({ message: "Invalid role" });
    return;
  }

  const [updated] = await db
    .update(usersTable)
    .set({ role })
    .where(eq(usersTable.id, user.id))
    .returning();

  res.json({
    id: updated.id,
    githubId: updated.githubId,
    name: updated.name,
    email: updated.email ?? null,
    avatarUrl: updated.avatarUrl ?? null,
    bio: updated.bio ?? null,
    role: updated.role,
    createdAt: updated.createdAt,
  });
});

export default router;
