import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useGithubOAuthCallback } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";
import { toast } from "@/components/ui";

export default function AuthCallback() {
  const [searchParams] = new URLSearchParams(window.location.search);
  const code = searchParams.get("code");
  const state = searchParams.get("state");
  const [_, setLocation] = useLocation();
  const { login } = useAuth();
  const [processed, setProcessed] = useState(false);

  const { data, isError, error } = useGithubOAuthCallback(
    { code: code!, state: state || undefined },
    { query: { enabled: !!code && !processed, retry: false } }
  );

  useEffect(() => {
    if (!code) {
      setLocation("/");
      return;
    }

    if (data && !processed) {
      setProcessed(true);
      login(data.token);
      toast("Successfully logged in!");
      setLocation("/");
    }

    if (isError) {
      setProcessed(true);
      toast("Authentication failed. Please try again.", "error");
      console.error(error);
      setLocation("/");
    }
  }, [data, isError, code, login, setLocation, processed, error]);

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center">
      <div className="bg-card p-8 rounded-3xl shadow-2xl border border-border text-center max-w-md w-full">
        <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Authenticating</h2>
        <p className="text-muted-foreground font-medium">Please wait while we securely log you in...</p>
      </div>
    </div>
  );
}
