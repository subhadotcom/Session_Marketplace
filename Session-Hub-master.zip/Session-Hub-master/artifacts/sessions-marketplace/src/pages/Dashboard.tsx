import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useGetUserBookings, useCancelBooking, useUpdateProfile, useUpdateRole } from "@workspace/api-client-react";
import { Button, Card, Input, Textarea, Badge, toast } from "@/components/ui";
import { format } from "date-fns";
import { Calendar, Clock, Settings, User as UserIcon, LogOut, ArrowRight, XCircle } from "lucide-react";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { getGetUserBookingsQueryKey } from "@workspace/api-client-react";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<"bookings" | "profile">("bookings");
  const queryClient = useQueryClient();

  const { data: bookingsData, isLoading: bookingsLoading } = useGetUserBookings();
  
  const { mutate: cancelBooking, isPending: isCancelling } = useCancelBooking({
    mutation: {
      onSuccess: () => {
        toast("Booking cancelled successfully.");
        queryClient.invalidateQueries({ queryKey: getGetUserBookingsQueryKey() });
      }
    }
  });

  const { mutate: updateProfile, isPending: isUpdating } = useUpdateProfile({
    mutation: {
      onSuccess: () => toast("Profile updated successfully!"),
      onError: () => toast("Failed to update profile", "error")
    }
  });

  const { mutate: becomeCreator, isPending: isBecoming } = useUpdateRole({
    mutation: {
      onSuccess: () => {
        toast("You are now a Creator!");
        window.location.reload(); // Hard reload to refresh auth context role fully
      }
    }
  });

  const handleProfileSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    updateProfile({
      data: {
        name: fd.get("name") as string,
        bio: fd.get("bio") as string,
        avatarUrl: fd.get("avatarUrl") as string,
      }
    });
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background pb-20 pt-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="flex items-center gap-6">
            <img 
              src={user.avatarUrl || `${import.meta.env.BASE_URL}images/avatar-placeholder.png`} 
              alt={user.name} 
              className="w-24 h-24 rounded-3xl object-cover shadow-xl border-4 border-white"
            />
            <div>
              <h1 className="text-4xl font-display font-black text-foreground">{user.name}</h1>
              <p className="text-lg font-medium text-muted-foreground capitalize">{user.role} Account</p>
            </div>
          </div>
          
          {user.role === 'user' && (
            <Card className="p-4 flex items-center gap-4 bg-gradient-to-r from-accent/10 to-transparent border-accent/20 max-w-sm">
              <div>
                <p className="font-bold text-foreground">Want to host sessions?</p>
                <p className="text-sm text-muted-foreground">Upgrade to a creator account.</p>
              </div>
              <Button size="sm" variant="accent" onClick={() => becomeCreator({ data: { role: 'creator' } })} isLoading={isBecoming}>
                Upgrade
              </Button>
            </Card>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-4 border-b border-border mb-8">
          <button 
            className={`pb-4 px-2 text-lg font-bold transition-all ${activeTab === 'bookings' ? 'text-primary border-b-2 border-primary' : 'text-muted-foreground hover:text-foreground'}`}
            onClick={() => setActiveTab('bookings')}
          >
            My Bookings
          </button>
          <button 
            className={`pb-4 px-2 text-lg font-bold transition-all ${activeTab === 'profile' ? 'text-primary border-b-2 border-primary' : 'text-muted-foreground hover:text-foreground'}`}
            onClick={() => setActiveTab('profile')}
          >
            Profile Settings
          </button>
        </div>

        {/* Content */}
        {activeTab === 'bookings' && (
          <div className="space-y-6">
            {bookingsLoading ? (
              <div className="h-64 flex items-center justify-center"><div className="animate-spin h-8 w-8 border-b-2 border-primary rounded-full"></div></div>
            ) : bookingsData?.bookings.length === 0 ? (
              <Card className="p-12 text-center border-dashed">
                <Calendar className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
                <h3 className="text-2xl font-bold">No bookings yet</h3>
                <p className="text-muted-foreground mt-2 mb-6">You haven't booked any sessions. Find something interesting!</p>
                <Link href="/">
                  <Button>Explore Sessions</Button>
                </Link>
              </Card>
            ) : (
              <div className="grid gap-6">
                {bookingsData?.bookings.map((booking) => (
                  <Card key={booking.id} className="p-6 flex flex-col sm:flex-row gap-6 items-start sm:items-center hover:shadow-md transition-shadow">
                    <div className="w-full sm:w-48 h-32 rounded-xl bg-muted overflow-hidden shrink-0">
                      {booking.session.imageUrl ? (
                        <img src={booking.session.imageUrl} className="w-full h-full object-cover" alt="Session" />
                      ) : (
                        <div className="w-full h-full bg-primary/10"></div>
                      )}
                    </div>
                    
                    <div className="flex-1 space-y-2">
                      <div className="flex justify-between items-start">
                        <Link href={`/sessions/${booking.session.id}`} className="text-xl font-bold hover:text-primary transition-colors">
                          {booking.session.title}
                        </Link>
                        <Badge variant={booking.status === 'active' ? 'success' : 'default'} className="uppercase text-xs tracking-wider">
                          {booking.status}
                        </Badge>
                      </div>
                      
                      <p className="text-muted-foreground line-clamp-1">{booking.session.description}</p>
                      
                      <div className="flex flex-wrap gap-4 pt-2 text-sm font-semibold text-foreground">
                        <div className="flex items-center gap-1.5 bg-muted/50 px-3 py-1.5 rounded-lg">
                          <Calendar className="w-4 h-4 text-primary" />
                          {format(new Date(booking.session.scheduledAt), "MMM d, yyyy h:mm a")}
                        </div>
                        <div className="flex items-center gap-1.5 bg-muted/50 px-3 py-1.5 rounded-lg">
                          <Clock className="w-4 h-4 text-primary" />
                          {booking.session.duration} min
                        </div>
                      </div>
                    </div>

                    <div className="w-full sm:w-auto flex sm:flex-col gap-3 justify-end shrink-0 border-t sm:border-t-0 sm:border-l border-border pt-4 sm:pt-0 sm:pl-6">
                      <Link href={`/sessions/${booking.session.id}`}>
                        <Button variant="outline" className="w-full">View Details</Button>
                      </Link>
                      {booking.status === 'active' && (
                        <Button 
                          variant="destructive" 
                          className="w-full"
                          onClick={() => {
                            if(confirm("Are you sure you want to cancel this booking?")) cancelBooking({ id: booking.id });
                          }}
                          disabled={isCancelling}
                        >
                          <XCircle className="w-4 h-4 mr-2" /> Cancel
                        </Button>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="grid md:grid-cols-2 gap-12">
            <Card className="p-8">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Settings className="w-6 h-6 text-primary" /> Profile Information
              </h2>
              <form onSubmit={handleProfileSubmit} className="space-y-6">
                <Input name="name" label="Full Name" defaultValue={user.name} required />
                <Input name="avatarUrl" label="Avatar URL" defaultValue={user.avatarUrl || ''} placeholder="https://..." />
                <Textarea name="bio" label="Bio" defaultValue={user.bio || ''} placeholder="Tell us about yourself..." />
                
                <Button type="submit" className="w-full" isLoading={isUpdating}>Save Changes</Button>
              </form>
            </Card>

            <div className="space-y-6">
              <Card className="p-8 bg-destructive/5 border-destructive/20">
                <h2 className="text-2xl font-bold mb-2 text-destructive">Account Actions</h2>
                <p className="text-muted-foreground mb-6">Manage your session and securely log out.</p>
                <Button variant="destructive" onClick={logout} className="w-full sm:w-auto">
                  <LogOut className="w-4 h-4 mr-2" /> Sign Out
                </Button>
              </Card>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
