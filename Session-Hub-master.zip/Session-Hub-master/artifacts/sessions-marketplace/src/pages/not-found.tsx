import { Link } from "wouter";
import { Button } from "@/components/ui";
import { SearchX } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center px-4 text-center">
      <div className="w-24 h-24 bg-primary/10 rounded-3xl flex items-center justify-center mb-8 rotate-12">
        <SearchX className="w-12 h-12 text-primary -rotate-12" />
      </div>
      <h1 className="text-5xl font-display font-black text-foreground mb-4">Page not found</h1>
      <p className="text-xl text-muted-foreground max-w-md mb-8">
        The page you're looking for doesn't exist or has been moved.
      </p>
      <Link href="/">
        <Button size="lg">Return Home</Button>
      </Link>
    </div>
  );
}
