import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useGetCreatorSessions, useCreateSession, useDeleteSession, useGetSessionBookings } from "@workspace/api-client-react";
import { Button, Card, Input, Textarea, Badge, Modal, toast } from "@/components/ui";
import { format } from "date-fns";
import { Calendar, Users, Plus, Edit, Trash2, TrendingUp, DollarSign } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/utils";

export default function CreatorDashboard() {
  const { user } = useAuth();
  const [_, setLocation] = useLocation();
  const queryClient = useQueryClient();
  
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [viewBookingsSessionId, setViewBookingsSessionId] = useState<number | null>(null);

  // Redirect if not creator
  if (user && user.role !== 'creator') {
    setLocation('/dashboard');
    return null;
  }

  const { data, isLoading } = useGetCreatorSessions();
  
  const { mutate: createSession, isPending: isCreating } = useCreateSession({
    mutation: {
      onSuccess: () => {
        toast("Session created successfully!");
        setIsCreateModalOpen(false);
        queryClient.invalidateQueries({ queryKey: ["/api/sessions/creator/my"] });
      },
      onError: (err: any) => toast(err.message || "Failed to create session", "error")
    }
  });

  const { mutate: deleteSession, isPending: isDeleting } = useDeleteSession({
    mutation: {
      onSuccess: () => {
        toast("Session deleted.");
        queryClient.invalidateQueries({ queryKey: ["/api/sessions/creator/my"] });
      }
    }
  });

  const handleCreateSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const dateStr = fd.get("scheduledAt") as string;
    
    createSession({
      data: {
        title: fd.get("title") as string,
        description: fd.get("description") as string,
        category: fd.get("category") as string,
        price: Number(fd.get("price")),
        duration: Number(fd.get("duration")),
        maxParticipants: fd.get("maxParticipants") ? Number(fd.get("maxParticipants")) : undefined,
        scheduledAt: new Date(dateStr).toISOString(),
        imageUrl: fd.get("imageUrl") as string || undefined,
      }
    });
  };

  const totalEarnings = data?.sessions.reduce((acc, curr) => acc + (curr.price * curr.bookingCount), 0) || 0;
  const totalBookings = data?.sessions.reduce((acc, curr) => acc + curr.bookingCount, 0) || 0;

  return (
    <div className="min-h-screen bg-slate-50 pb-20 pt-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
          <div>
            <h1 className="text-4xl font-display font-black text-foreground">Creator Studio</h1>
            <p className="text-lg text-muted-foreground mt-1">Manage your sessions and track your success.</p>
          </div>
          <Button size="lg" onClick={() => setIsCreateModalOpen(true)} className="shadow-primary/30">
            <Plus className="w-5 h-5 mr-2" /> Create New Session
          </Button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10">
          <Card className="p-6 bg-gradient-to-br from-primary to-primary/80 text-white border-none shadow-xl shadow-primary/20">
            <DollarSign className="w-8 h-8 opacity-80 mb-4" />
            <p className="text-primary-foreground/80 font-medium">Estimated Earnings</p>
            <h2 className="text-4xl font-black font-display">{formatCurrency(totalEarnings)}</h2>
          </Card>
          <Card className="p-6 border-none shadow-lg">
            <Users className="w-8 h-8 text-accent mb-4" />
            <p className="text-muted-foreground font-medium">Total Bookings</p>
            <h2 className="text-4xl font-black font-display text-foreground">{totalBookings}</h2>
          </Card>
          <Card className="p-6 border-none shadow-lg">
            <TrendingUp className="w-8 h-8 text-green-500 mb-4" />
            <p className="text-muted-foreground font-medium">Active Sessions</p>
            <h2 className="text-4xl font-black font-display text-foreground">{data?.sessions.filter(s => s.isActive).length || 0}</h2>
          </Card>
        </div>

        <h2 className="text-2xl font-bold mb-6">Your Sessions</h2>
        
        {isLoading ? (
           <div className="h-64 flex items-center justify-center"><div className="animate-spin h-8 w-8 border-b-2 border-primary rounded-full"></div></div>
        ) : data?.sessions.length === 0 ? (
          <Card className="p-16 text-center border-dashed">
            <Presentation className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
            <h3 className="text-2xl font-bold">No sessions created</h3>
            <p className="text-muted-foreground mt-2 mb-6">Share your expertise with the world by creating your first session.</p>
            <Button onClick={() => setIsCreateModalOpen(true)}>Create Session</Button>
          </Card>
        ) : (
          <div className="grid gap-6">
            {data?.sessions.map((session) => (
              <Card key={session.id} className="p-6 flex flex-col md:flex-row gap-6 items-start md:items-center">
                <div className="w-full md:w-64 aspect-video rounded-xl bg-muted overflow-hidden shrink-0">
                  <img src={session.imageUrl || "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=600&q=80"} className="w-full h-full object-cover" alt="Session" />
                </div>
                
                <div className="flex-1 space-y-3 w-full">
                  <div className="flex justify-between items-start">
                    <div>
                      <Badge className="mb-2">{session.category}</Badge>
                      <h3 className="text-2xl font-bold leading-tight">{session.title}</h3>
                    </div>
                    <Badge variant={session.isActive ? "success" : "default"}>{session.isActive ? "Active" : "Closed"}</Badge>
                  </div>
                  
                  <div className="flex flex-wrap gap-4 pt-2 text-sm font-semibold text-foreground">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4 text-primary" />
                      {format(new Date(session.scheduledAt), "MMM d, yyyy h:mm a")}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-accent" />
                      {session.bookingCount} / {session.maxParticipants || '∞'} Booked
                    </div>
                    <div className="flex items-center gap-1.5">
                      <DollarSign className="w-4 h-4 text-green-500" />
                      {formatCurrency(session.price)}
                    </div>
                  </div>
                </div>

                <div className="w-full md:w-auto flex md:flex-col gap-3 shrink-0 pt-4 md:pt-0 md:pl-6 md:border-l border-border">
                  <Button variant="secondary" className="w-full" onClick={() => setViewBookingsSessionId(session.id)}>
                    View Bookings
                  </Button>
                  <Button variant="outline" className="w-full" asChild>
                    <Link href={`/sessions/${session.id}`}>Public Page</Link>
                  </Button>
                  <Button 
                    variant="destructive" 
                    className="w-full" 
                    disabled={isDeleting}
                    onClick={() => {
                      if(confirm("Are you sure you want to delete this session?")) deleteSession({ id: session.id });
                    }}
                  >
                    <Trash2 className="w-4 h-4 mr-2" /> Delete
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}

      </div>

      {/* CREATE MODAL */}
      <Modal isOpen={isCreateModalOpen} onClose={() => setIsCreateModalOpen(false)} title="Create New Session">
        <form onSubmit={handleCreateSubmit} className="space-y-6">
          <Input name="title" label="Session Title" placeholder="e.g. Advanced System Design" required />
          <Textarea name="description" label="Description" placeholder="What will participants learn?" required />
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-foreground">Category</label>
              <select name="category" className="flex h-12 w-full rounded-xl border-2 border-border bg-background px-4 text-base focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none" required>
                <option value="Technology">Technology</option>
                <option value="Business">Business</option>
                <option value="Design">Design</option>
                <option value="Health">Health</option>
                <option value="Education">Education</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <Input name="price" label="Price (USD)" type="number" step="0.01" min="0" placeholder="0.00" required />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Input name="duration" label="Duration (minutes)" type="number" min="15" placeholder="60" required />
            <Input name="maxParticipants" label="Max Participants (Optional)" type="number" min="1" placeholder="Leave empty for unlimited" />
          </div>

          <Input name="scheduledAt" label="Scheduled Date & Time" type="datetime-local" required />
          <Input name="imageUrl" label="Cover Image URL (Optional)" placeholder="https://..." />

          <div className="pt-4 flex justify-end gap-3 border-t border-border">
            <Button variant="ghost" type="button" onClick={() => setIsCreateModalOpen(false)}>Cancel</Button>
            <Button type="submit" isLoading={isCreating}>Create Session</Button>
          </div>
        </form>
      </Modal>

      {/* VIEW BOOKINGS MODAL */}
      <BookingsModal 
        sessionId={viewBookingsSessionId} 
        onClose={() => setViewBookingsSessionId(null)} 
      />
    </div>
  );
}

// Sub-component for bookings modal to handle its own query cleanly
function BookingsModal({ sessionId, onClose }: { sessionId: number | null, onClose: () => void }) {
  const { data, isLoading } = useGetSessionBookings(sessionId || 0, { query: { enabled: !!sessionId } });

  return (
    <Modal isOpen={!!sessionId} onClose={onClose} title="Session Bookings">
      <div className="space-y-4">
        {isLoading ? (
          <div className="py-12 flex justify-center"><div className="animate-spin h-8 w-8 border-b-2 border-primary rounded-full"></div></div>
        ) : data?.bookings.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground">No one has booked this session yet.</div>
        ) : (
          <div className="space-y-3">
            <div className="flex justify-between text-sm font-semibold text-muted-foreground pb-2 border-b border-border">
              <span>User</span>
              <span>Status</span>
            </div>
            {data?.bookings.map((b) => (
              <div key={b.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-xl">
                <div className="flex items-center gap-3">
                  <img src={b.user.avatarUrl || `${import.meta.env.BASE_URL}images/avatar-placeholder.png`} className="w-10 h-10 rounded-full object-cover bg-background" />
                  <div>
                    <p className="font-bold text-foreground">{b.user.name}</p>
                    <p className="text-xs text-muted-foreground">{format(new Date(b.createdAt), "MMM d, yyyy")}</p>
                  </div>
                </div>
                <Badge variant={b.status === 'active' ? 'success' : 'default'} className="uppercase text-[10px]">
                  {b.status}
                </Badge>
              </div>
            ))}
          </div>
        )}
      </div>
    </Modal>
  );
}

// Re-declare for fallback
function Presentation(props: any) {
  return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round" {...props}><path d="M2 3h20"/><path d="M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"/><path d="m7 21 5-5 5 5"/></svg>;
}
