import { useState } from "react";
import { useListSessions } from "@workspace/api-client-react";
import { SessionCard } from "@/components/SessionCard";
import { Input, Button, Badge } from "@/components/ui";
import { Search, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

const CATEGORIES = ["All", "Technology", "Business", "Design", "Health", "Education", "Other"];

export default function Home() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");

  const { data, isLoading } = useListSessions({
    search: search || undefined,
    category: category !== "All" ? category : undefined,
  });

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Hero Section */}
      <section className="relative pt-24 pb-32 overflow-hidden flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          <img 
            src={`${import.meta.env.BASE_URL}images/hero-bg.png`} 
            alt="Hero background" 
            className="w-full h-full object-cover opacity-90 mix-blend-multiply"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/80 to-background" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center space-y-8 animate-slide-up">
          <Badge className="bg-white/80 backdrop-blur-md text-primary px-4 py-1.5 text-sm mb-4 border-none shadow-sm">
            <Sparkles className="w-4 h-4 mr-2 inline-block" />
            Discover Expert Knowledge
          </Badge>
          <h1 className="text-5xl sm:text-7xl font-display font-black text-foreground leading-[1.1]">
            Master new skills with <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              industry leaders
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-medium">
            Join exclusive, intimate sessions led by verified creators. Elevate your career, build your business, and learn from the best.
          </p>

          <div className="max-w-xl mx-auto relative pt-8">
            <div className="absolute inset-y-0 left-4 top-8 flex items-center pointer-events-none">
              <Search className="h-6 w-6 text-muted-foreground" />
            </div>
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search sessions, topics, or creators..."
              className="pl-14 h-16 text-lg rounded-full bg-white/90 backdrop-blur-md border-white/50 shadow-xl shadow-primary/5"
            />
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-20">
        
        {/* Categories */}
        <div className="flex items-center gap-3 overflow-x-auto pb-6 scrollbar-hide snap-x">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`snap-start whitespace-nowrap px-6 py-3 rounded-full text-sm font-bold transition-all duration-300 border-2 ${
                category === cat 
                  ? "bg-foreground text-background border-foreground shadow-md" 
                  : "bg-white text-muted-foreground border-border hover:border-primary/50 hover:text-foreground"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="mt-8">
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                <div key={n} className="h-[400px] bg-card rounded-3xl animate-pulse border border-border" />
              ))}
            </div>
          ) : data?.sessions.length === 0 ? (
            <div className="text-center py-32 bg-white rounded-3xl border border-border border-dashed mt-8">
              <img src={`${import.meta.env.BASE_URL}images/empty-state.png`} className="w-48 h-48 mx-auto mb-6 opacity-80" alt="Empty" />
              <h3 className="text-2xl font-bold text-foreground">No sessions found</h3>
              <p className="text-muted-foreground mt-2">Try adjusting your search or category filter.</p>
              <Button variant="outline" className="mt-6" onClick={() => {setSearch(""); setCategory("All");}}>
                Clear Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {data?.sessions.map((session, i) => (
                <motion.div
                  key={session.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05, duration: 0.4 }}
                >
                  <SessionCard session={session} />
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
