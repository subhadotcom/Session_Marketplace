import { useParams, Link, useLocation } from "wouter";
import { useGetSession, useCreateBooking, getGithubOAuthRedirectUrl } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button, Card, Badge, toast } from "@/components/ui";
import { format } from "date-fns";
import { Calendar, Clock, Users, ArrowLeft, ShieldCheck, Share2 } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

export default function SessionDetail() {
  const { id } = useParams();
  const [_, setLocation] = useLocation();
  const { user } = useAuth();
  
  const { data: session, isLoading, isError } = useGetSession(Number(id));

  const { mutate: bookSession, isPending: isBooking } = useCreateBooking({
    mutation: {
      onSuccess: () => {
        toast("Successfully booked session!");
        setLocation("/dashboard");
      },
      onError: (err: any) => {
        toast(err.message || "Failed to book session", "error");
      }
    }
  });

  if (isLoading) return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;
  if (isError || !session) return <div className="min-h-screen flex items-center justify-center"><h1 className="text-2xl font-bold">Session not found</h1></div>;

  const handleBook = () => {
    if (!user) {
      window.location.href = getGithubOAuthRedirectUrl();
      return;
    }
    bookSession({ data: { sessionId: session.id } });
  };

  {/* stock image fallback for details if not provided by creator */}
  const imageSrc = session.imageUrl || "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=1200&q=80";

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/" className="inline-flex items-center text-sm font-bold text-muted-foreground hover:text-primary mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to explore
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-10">
            <div className="rounded-3xl overflow-hidden shadow-2xl shadow-primary/5 border border-border">
              <img src={imageSrc} alt={session.title} className="w-full aspect-[21/9] object-cover" />
            </div>

            <div className="space-y-6">
              <div className="flex items-center gap-3 flex-wrap">
                <Badge className="bg-primary/10 text-primary hover:bg-primary/20 text-sm px-4 py-1.5">{session.category}</Badge>
                {session.maxParticipants && (
                  <Badge variant="secondary" className="bg-muted text-muted-foreground text-sm px-4 py-1.5">
                    <Users className="w-3.5 h-3.5 mr-1.5 inline" />
                    Limited to {session.maxParticipants} seats
                  </Badge>
                )}
              </div>

              <h1 className="text-4xl sm:text-5xl font-display font-black text-foreground leading-tight">
                {session.title}
              </h1>

              <div className="flex items-center gap-4 py-4 border-y border-border">
                <img 
                  src={session.creator.avatarUrl || `${import.meta.env.BASE_URL}images/avatar-placeholder.png`} 
                  alt={session.creator.name} 
                  className="w-14 h-14 rounded-full object-cover bg-muted"
                />
                <div>
                  <p className="text-sm font-semibold text-muted-foreground">Hosted by</p>
                  <p className="text-lg font-bold text-foreground">{session.creator.name}</p>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold mb-4">About this session</h3>
                <div className="prose prose-lg prose-slate text-muted-foreground whitespace-pre-wrap">
                  {session.description}
                </div>
              </div>
            </div>
          </div>

          {/* Booking Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-28">
              <Card className="p-8 shadow-2xl shadow-primary/10 border-2 border-border/50">
                <div className="flex items-end gap-2 mb-6">
                  <span className="text-4xl font-display font-black text-foreground">{formatCurrency(session.price)}</span>
                  <span className="text-muted-foreground font-semibold mb-1">USD</span>
                </div>

                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-4 text-foreground font-semibold bg-muted/50 p-4 rounded-xl">
                    <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                      <Calendar className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground font-medium">Date & Time</p>
                      <p>{format(new Date(session.scheduledAt), "MMMM d, yyyy 'at' h:mm a")}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-foreground font-semibold bg-muted/50 p-4 rounded-xl">
                    <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                      <Clock className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground font-medium">Duration</p>
                      <p>{session.duration} minutes</p>
                    </div>
                  </div>
                </div>

                <Button 
                  size="lg" 
                  className="w-full text-lg shadow-xl shadow-primary/30" 
                  onClick={handleBook}
                  isLoading={isBooking}
                  disabled={!session.isActive}
                >
                  {!session.isActive ? "Session Closed" : user ? "Book Now" : "Login to Book"}
                </Button>

                <div className="mt-6 flex items-center justify-center gap-2 text-sm font-semibold text-muted-foreground">
                  <ShieldCheck className="w-4 h-4 text-green-500" />
                  Secure checkout & buyer protection
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
