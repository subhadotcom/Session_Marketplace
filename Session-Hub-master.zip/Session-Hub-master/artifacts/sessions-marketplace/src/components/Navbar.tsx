import { Link } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "./ui";
import { LayoutDashboard, LogOut, Compass, Presentation } from "lucide-react";
import { getGithubOAuthRedirectUrl } from "@workspace/api-client-react";

export function Navbar() {
  const { user, isLoading, logout } = useAuth();

  const handleLogin = () => {
    window.location.href = getGithubOAuthRedirectUrl();
  };

  return (
    <header className="sticky top-0 z-40 w-full glass-panel">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-all duration-300 group-hover:-translate-y-0.5">
            <Compass className="w-6 h-6 text-white" />
          </div>
          <span className="font-display font-bold text-2xl tracking-tight text-foreground">
            Sessions<span className="text-primary">Market</span>
          </span>
        </Link>

        <nav className="flex items-center gap-4 sm:gap-6">
          <Link href="/" className="text-sm font-semibold text-muted-foreground hover:text-primary transition-colors hidden sm:block">
            Explore
          </Link>

          {!isLoading && (
            <>
              {user ? (
                <div className="flex items-center gap-3 border-l pl-6 border-border">
                  <div className="flex flex-col items-end hidden md:flex">
                    <span className="text-sm font-bold text-foreground leading-tight">{user.name}</span>
                    <span className="text-xs font-semibold text-primary capitalize">{user.role}</span>
                  </div>
                  
                  {user.role === 'creator' ? (
                    <Link href="/creator">
                      <Button variant="outline" size="sm" className="gap-2 rounded-full border-dashed">
                        <Presentation className="w-4 h-4" />
                        <span className="hidden sm:inline">Creator</span>
                      </Button>
                    </Link>
                  ) : null}

                  <Link href="/dashboard">
                    <Button variant="ghost" size="icon" className="rounded-full bg-muted">
                      {user.avatarUrl ? (
                        <img src={user.avatarUrl} alt={user.name} className="w-full h-full rounded-full object-cover" />
                      ) : (
                        <LayoutDashboard className="w-5 h-5 text-foreground" />
                      )}
                    </Button>
                  </Link>
                  
                  <Button variant="ghost" size="icon" onClick={logout} title="Logout">
                    <LogOut className="w-5 h-5 text-muted-foreground" />
                  </Button>
                </div>
              ) : (
                <Button onClick={handleLogin} size="md">
                  Login with GitHub
                </Button>
              )}
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
