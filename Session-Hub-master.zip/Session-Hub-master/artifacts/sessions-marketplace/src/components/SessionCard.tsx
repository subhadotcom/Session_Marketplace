import { Link } from "wouter";
import type { Session } from "@workspace/api-client-react";
import { format } from "date-fns";
import { Badge } from "./ui";
import { Clock, Calendar, Users } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

export function SessionCard({ session }: { session: Session }) {
  return (
    <Link href={`/sessions/${session.id}`} className="group block h-full">
      <div className="h-full bg-card rounded-3xl border border-border overflow-hidden shadow-[0_4px_20px_rgb(0,0,0,0.03)] hover:shadow-[0_20px_40px_rgb(0,0,0,0.08)] hover:-translate-y-1.5 transition-all duration-300 ease-out flex flex-col">
        <div className="relative aspect-[4/3] w-full overflow-hidden bg-muted">
          {session.imageUrl ? (
            <img 
              src={session.imageUrl} 
              alt={session.title} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center">
              <Compass className="w-12 h-12 text-primary/20" />
            </div>
          )}
          <div className="absolute top-4 left-4">
            <Badge className="bg-white/90 backdrop-blur-md border-none text-foreground shadow-sm">{session.category}</Badge>
          </div>
          <div className="absolute top-4 right-4">
            <Badge variant="success" className="bg-green-400/90 text-white backdrop-blur-md border-none shadow-sm text-sm py-1">
              {formatCurrency(session.price)}
            </Badge>
          </div>
        </div>

        <div className="p-6 flex flex-col flex-1">
          <h3 className="font-display text-xl font-bold text-foreground line-clamp-2 leading-tight group-hover:text-primary transition-colors">
            {session.title}
          </h3>
          
          <p className="mt-2 text-sm text-muted-foreground line-clamp-2 flex-1">
            {session.description}
          </p>

          <div className="mt-6 pt-4 border-t border-border flex items-center justify-between">
            <div className="flex items-center gap-2">
              {session.creator?.avatarUrl ? (
                <img src={session.creator.avatarUrl} alt="Creator" className="w-8 h-8 rounded-full object-cover bg-muted" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-xs font-bold text-primary">{session.creator?.name?.charAt(0) || 'C'}</span>
                </div>
              )}
              <span className="text-sm font-semibold text-foreground truncate max-w-[120px]">
                {session.creator?.name || 'Unknown'}
              </span>
            </div>

            <div className="flex flex-col items-end gap-1 text-xs font-medium text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                {format(new Date(session.scheduledAt), "MMM d")}
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                {session.duration} min
              </div>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

// Re-declaring icon here for fallback since it's missing in imports of this specific file chunk
function Compass(props: any) {
  return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinelinejoin="round" {...props}><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>;
}
