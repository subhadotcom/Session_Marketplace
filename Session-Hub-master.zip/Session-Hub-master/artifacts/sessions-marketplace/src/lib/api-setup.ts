/**
 * Global fetch interceptor to inject Authorization header
 * MUST be imported at the very top of App.tsx before any queries run
 */
const originalFetch = window.fetch;

window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
  let url = '';
  if (typeof input === 'string') url = input;
  else if (input instanceof URL) url = input.toString();
  else if (input instanceof Request) url = input.url;

  // Only intercept API calls
  if (url.startsWith('/api') || url.includes(window.location.origin)) {
    const token = localStorage.getItem('auth_token');
    
    if (token) {
      const headers = new Headers(init?.headers);
      headers.set('Authorization', `Bearer ${token}`);
      init = { ...init, headers };
    }
  }

  return originalFetch(input, init);
};
